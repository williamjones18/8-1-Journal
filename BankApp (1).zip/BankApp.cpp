//============================================================================
// Name        : BankApp.cpp
// Author      : William Jones
// Version     :
// Copyright   :
// Description :
//============================================================================

#include <iostream>
#include <conio.h>
#include <iomanip>
using namespace std;

int main() {
	int months;  			//the value of months of data to list
	double openingAmount;	//the value of the opening amount in the account
	double depositedAmount; //the value of the monthly deposits
	double total;			//the value of the total earned for the month
	double annualInterest;	//the value of the annual interest rate
	int years;				//the value of years of data to list
	double interest;		//the value of the current interest to apply

	cout << "Enter Initial Investment Amount:" << endl;
	cin >> openingAmount;									//stores user input in openingAmount
	cout << "Enter Monthly Deposit:" << endl;
	cin >> depositedAmount;									//stores user input in depositedAmount
	cout << "Enter Annual Interest:" << endl;
	cin >> annualInterest;									//stores user input in annualInterest
	cout << "Enter Number of years:" << endl;
	cin >> years;											//stores user input in years
	months = 12 * years;									//multiplies years by 12 to account for months
	total = openingAmount;									//the initial total is set to the opening amount

	cout << "****************************" << endl;
	cout << "******* Data Input *********" << endl;
	cout << "Initial Investment Amount: " << openingAmount << endl; //outputs Initial Investment Amount
	cout << "Monthly Deposit: " << depositedAmount << endl;			//outputs Monthly Deposit
	cout << "Annual Interest: " << annualInterest << "%" << endl;	//outputs Annual Interest
	cout << "Number of years: " << years << endl;					//outputs Number of years
    system("pause");												//prints press any key to continue and waits for user to press key

	cout << string(100, '\n');										//clear screen
	if(depositedAmount == 0){										//if the deposited amount is 0, prints
		cout << " Balance and Interest without Additional "			//" Balance and Interest without Additional "
				"Monthly Deposits" << endl;
    }else{															//or else prints
    	cout << " Balance and Interest with Additional "			//" Balance and Interest with Additional "
    					"Monthly Deposits" << endl;
    }
	cout << "=========================================================" << endl;
	cout << "Month      Month End Balance     Month End "
			"Earned Interest" << endl;
	cout << "---------------------------------------------------------" << endl;
	cout << fixed << setprecision(2);												//sets the precision of the values to account for
	interest = annualInterest;														//decimal places to always be shown.
	for(int i = 1 ; i < months+1; i ++){											//for as long as the current month is less than 1
		interest =  (int) (i * (openingAmount + depositedAmount) *					//more than the last month,
				   (annualInterest)/12)/100.0;										//calculates interest according to given formula.
        total = total + depositedAmount + interest;									//calculates the sum of the deposits, interest,
        																			//and previous total
        if(total < 100){
            cout << i << "                    " << total << "                         " << interest << endl; //outputs the data
        }else{
            cout << i << "                   " <<  total << "                         " << interest << endl;
        }
    }
	return 0;
}
